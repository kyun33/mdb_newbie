function NewScreen() {
  return (
    
    <View style={styles.container}>
      <Text style={styles.title}>This is a New Screen!</Text>
    </View>
  );
}

export default NewScreen;
